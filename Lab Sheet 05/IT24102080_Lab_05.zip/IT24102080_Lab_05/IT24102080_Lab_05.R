getwd()
setwd("E://SLIIT//files//Y2S1//PS//Labs//IT24102080_PS_Lab_05//IT24102080_Lab_05")
getwd()

#01
Delivery_Times <- read.table("Exercise - Lab 05.txt", header = TRUE)

Delivery_Times$Delivery_Time_.minutes. <- as.numeric(Delivery_Times$Delivery_Time_.minutes.)

#02
hist(Delivery_Times$Delivery_Time_.minutes.,
     breaks = seq(20, 70, by = 5),
     right = TRUE,
     col = "lightblue",
     main = "Histogram of Delivery Times",
     xlab = "Delivery Time",
     ylab = "Frequency")

#03
#Histogram has a right aligned skewness
#30-50 delivery time has the highest frequency.
#There are less observations in above 60 minutes delivery times compared to below 60 minutes.

#04
cf <- cumsum(table(cut(Delivery_Times$Delivery_Time_.minutes., breaks = seq(20, 70, by = 5), right = TRUE)))

plot(seq(22.5, 67.5, by = 5), cf, type = "o", col = "black",
     xlab = "Delivery Time", ylab = "Cumulative Frequency",
     main = "Cumulative Frequency Polygon (Ogive)")