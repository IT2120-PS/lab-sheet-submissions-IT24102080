# Exercise 1: Uniform Distribution for Train Arrival
# X ~ Uniform(0, 40) minutes after 8:00 a.m.
# P(10 < X < 25) = punif(25, min=0, max=40) - punif(10, min=0, max=40)

prob_train <- punif(25, min=0, max=40, lower.tail=TRUE) - punif(10, min=0, max=40, lower.tail=TRUE)
print(prob_train)

# Exercise 2: Exponential Distribution for Software Update
# X ~ Exponential(rate = 1/3)
# P(X <= 2)

prob_update <- pexp(2, rate=1/3, lower.tail=TRUE)
print(prob_update)

# Exercise 3: Normal Distribution for IQ Scores
# X ~ Normal(mean=100, sd=15)

# i. P(X > 130) = 1 - pnorm(130, mean=100, sd=15)
prob_iq_above_130 <- 1 - pnorm(130, mean=100, sd=15)
print(prob_iq_above_130)

# ii. 95th percentile: qnorm(0.95, mean=100, sd=15)
iq_95th_percentile <- qnorm(0.95, mean=100, sd=15)
print(iq_95th_percentile)